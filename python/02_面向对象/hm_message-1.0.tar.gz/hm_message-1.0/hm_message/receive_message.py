def receive():
    print('收到来自 100xx 短信')

